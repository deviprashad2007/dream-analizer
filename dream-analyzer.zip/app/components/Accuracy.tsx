import { CheckCircle } from 'lucide-react'

export default function Accuracy() {
  return (
    <div className="bg-indigo-700">
      <div className="max-w-2xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
          <span className="block">Specialized and Accurate Dream Analysis</span>
        </h2>
        <p className="mt-4 text-lg leading-6 text-indigo-200">
          Our AI is trained on extensive psychological research and dream interpretation techniques.
        </p>
        <ul className="mt-8 space-y-4">
          <li className="flex items-center justify-center text-indigo-200">
            <CheckCircle className="flex-shrink-0 w-5 h-5 text-green-500 mr-2" />
            <span>95% accuracy in identifying common dream symbols</span>
          </li>
          <li className="flex items-center justify-center text-indigo-200">
            <CheckCircle className="flex-shrink-0 w-5 h-5 text-green-500 mr-2" />
            <span>Personalized analysis based on your unique experiences</span>
          </li>
          <li className="flex items-center justify-center text-indigo-200">
            <CheckCircle className="flex-shrink-0 w-5 h-5 text-green-500 mr-2" />
            <span>Continuous learning from user feedback and new research</span>
          </li>
        </ul>
        <a
          href="#"
          className="mt-8 w-full inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-indigo-50 sm:w-auto"
        >
          Learn about our AI
        </a>
      </div>
    </div>
  )
}

