import { Brain, Sparkles, Star } from 'lucide-react'

const features = [
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Our advanced AI technology provides deep insights into your dreams, analyzing patterns and symbols with remarkable accuracy."
  },
  {
    icon: Sparkles,
    title: "Personal Insights",
    description: "Get personalized interpretations that take into account your unique experiences and emotional context."
  },
  {
    icon: Star,
    title: "Dream Patterns",
    description: "Track and understand recurring themes in your dreams, helping you uncover deeper meanings in your subconscious mind."
  }
]

export default function Features() {
  return (
    <div className="py-24 bg-white" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {features.map((feature, index) => (
            <div key={index} className="relative">
              <div className="flex flex-col items-center text-center">
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-indigo-100 text-indigo-600 mb-4">
                  <feature.icon className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-base text-gray-500">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

