import { Check } from 'lucide-react'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'month',
    features: [
      '10 dream analyses',
      'Basic symbol interpretation',
      'Daily dream journal',
      'Community access'
    ],
    buttonText: 'Get Started',
    buttonVariant: 'outline' as const
  },
  {
    name: 'Pro',
    price: '$9.99',
    period: 'month',
    features: [
      'Unlimited dream analyses',
      'Advanced symbol library',
      'AI-powered insights',
      'Priority support',
      'Expert consultation',
      'Sleep tracking integration'
    ],
    buttonText: 'Upgrade to Pro',
    buttonVariant: 'default' as const
  }
]

export default function PricingCards() {
  return (
    <div className="py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2 md:gap-12 lg:gap-16">
          {plans.map((plan) => (
            <Card key={plan.name} className="flex flex-col border-2 border-dream-200">
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="flex items-baseline text-2xl font-semibold">
                  {plan.price}
                  <span className="ml-1 text-sm font-normal text-muted-foreground">
                    /{plan.period}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="h-4 w-4 text-dream-600 mr-2 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button 
                  variant={plan.buttonVariant} 
                  className={`w-full ${plan.buttonVariant === 'default' ? 'bg-dream-600 hover:bg-dream-700' : 'border-dream-600 text-dream-600 hover:bg-dream-50'}`}
                >
                  {plan.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

