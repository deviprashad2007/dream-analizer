import { Check } from 'lucide-react'

export default function PremiumCard() {
  return (
    <div className="bg-white shadow-xl rounded-lg overflow-hidden lg:max-w-none lg:flex">
      <div className="bg-white px-6 py-8 lg:flex-shrink-1 lg:p-12">
        <h3 className="text-2xl leading-8 font-extrabold text-gray-900 sm:text-3xl sm:leading-9">
          Premium Dream Analysis
        </h3>
        <p className="mt-6 text-base leading-6 text-gray-500">
          Unlock advanced features and get deeper insights into your dreams with our premium plan.
        </p>
        <div className="mt-8">
          <div className="flex items-center">
            <h4 className="flex-shrink-0 pr-4 bg-white text-sm leading-5 tracking-wider font-semibold uppercase text-indigo-600">
              What's included
            </h4>
            <div className="flex-1 border-t-2 border-gray-200"></div>
          </div>
          <ul className="mt-8 space-y-5 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-x-8 lg:gap-y-5">
            {[
              'Unlimited dream analyses',
              'Personalized dream patterns',
              'Advanced symbol dictionary',
              'Integration with sleep tracking',
              'Weekly insight reports',
              'Expert consultation (1/month)',
            ].map((feature) => (
              <li key={feature} className="flex items-start lg:col-span-1">
                <div className="flex-shrink-0">
                  <Check className="h-5 w-5 text-green-400" aria-hidden="true" />
                </div>
                <p className="ml-3 text-sm leading-5 text-gray-700">{feature}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="py-8 px-6 text-center bg-gray-50 lg:flex-shrink-0 lg:flex lg:flex-col lg:justify-center lg:p-12">
        <p className="text-lg leading-6 font-medium text-gray-900">
          Pay once, analyze forever
        </p>
        <div className="mt-4 flex items-center justify-center text-5xl leading-none font-extrabold text-gray-900">
          <span>$99</span>
          <span className="ml-3 text-xl leading-7 font-medium text-gray-500">USD</span>
        </div>
        <p className="mt-4 text-sm leading-5 text-gray-500">
          One-time payment for lifetime access
        </p>
        <div className="mt-6">
          <div className="rounded-md shadow">
            <a
              href="#"
              className="flex items-center justify-center px-5 py-3 border border-transparent text-base leading-6 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:shadow-outline transition duration-150 ease-in-out"
            >
              Get Premium Access
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

