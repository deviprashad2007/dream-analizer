export default function AnalysisResult() {
  // In a real application, you'd fetch this data from your AI service
  const analysis = {
    summary: "Your dream suggests that you're processing recent changes in your life. The recurring theme of flying might represent your desire for freedom or escape from current responsibilities.",
    symbols: [
      { name: "Flying", meaning: "Desire for freedom, escaping responsibilities" },
      { name: "Water", meaning: "Emotions, subconscious mind" },
      { name: "Family", meaning: "Security, support system" },
    ],
    emotions: ["excitement", "anxiety", "relief"],
    advice: "Consider addressing any feelings of being overwhelmed in your waking life. The presence of family in your dream might indicate a need for support or connection."
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Dream Analysis</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Insights into your subconscious mind</p>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Summary</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{analysis.summary}</dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Symbols</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              <ul className="border border-gray-200 rounded-md divide-y divide-gray-200">
                {analysis.symbols.map((symbol, index) => (
                  <li key={index} className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                    <div className="w-0 flex-1 flex items-center">
                      <span className="ml-2 flex-1 w-0 truncate">{symbol.name}</span>
                    </div>
                    <div className="ml-4 flex-shrink-0">
                      <span className="font-medium text-indigo-600 hover:text-indigo-500">
                        {symbol.meaning}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Emotions</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {analysis.emotions.join(", ")}
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Advice</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{analysis.advice}</dd>
          </div>
        </dl>
      </div>
    </div>
  )
}

