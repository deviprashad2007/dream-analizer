import { BookOpen, Users, Trophy } from 'lucide-react'

const infoBoxes = [
  {
    icon: BookOpen,
    title: "Comprehensive Library",
    description: "Access our extensive database of dream symbols and their interpretations, backed by psychological research."
  },
  {
    icon: Users,
    title: "Community Insights",
    description: "Learn from others' experiences and share your own dream journey with our supportive community."
  },
  {
    icon: Trophy,
    title: "Expert Analysis",
    description: "Get professional insights from our team of experienced dream analysts and psychology experts."
  }
]

export default function ContentSection() {
  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
          <div className="relative">
            <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
              Understand Your Dreams Better
            </h2>
            <p className="mt-3 text-lg text-gray-500">
              Our AI-powered dream analysis platform combines cutting-edge technology with traditional dream interpretation techniques to provide you with meaningful insights into your subconscious mind. We help you uncover patterns, understand symbols, and gain valuable personal insights from your dreams.
            </p>
            <p className="mt-3 text-lg text-gray-500">
              Whether you're looking to understand recurring dreams, explore your subconscious thoughts, or simply curious about what your dreams might mean, our platform provides the tools and expertise you need to unlock these mysteries.
            </p>
          </div>
          <div className="mt-10 lg:mt-0 space-y-4">
            {infoBoxes.map((box, index) => (
              <div
                key={index}
                className="bg-white rounded-lg shadow-sm p-6 border border-gray-100 hover:border-indigo-100 transition-colors duration-200"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600">
                      <box.icon className="h-6 w-6" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">{box.title}</h3>
                    <p className="mt-2 text-base text-gray-500">{box.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

