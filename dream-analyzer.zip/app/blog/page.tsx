import Link from 'next/link'

// This would typically come from a database or CMS
const blogPosts = [
  {
    id: 1,
    title: "Understanding Common Dream Symbols",
    excerpt: "Learn about the most frequent symbols in dreams and what they might mean.",
    date: "2023-06-15"
  },
  {
    id: 2,
    title: "The Science of Sleep and Dreaming",
    excerpt: "Explore the latest research on how sleep affects our dream patterns.",
    date: "2023-06-10"
  },
  {
    id: 3,
    title: "Lucid Dreaming Techniques",
    excerpt: "Discover methods to become aware and take control in your dreams.",
    date: "2023-06-05"
  }
]

export default function BlogPage() {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Dream Analysis Blog</h1>
        <div className="grid gap-6 lg:grid-cols-2">
          {blogPosts.map((post) => (
            <div key={post.id} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">
                  <Link href={`/blog/${post.id}`} className="hover:underline">
                    {post.title}
                  </Link>
                </h2>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">{post.date}</span>
                  <Link href={`/blog/${post.id}`} className="text-indigo-600 hover:text-indigo-800">
                    Read more
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

