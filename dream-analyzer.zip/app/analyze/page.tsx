import DreamForm from '../components/DreamForm'
import AnalysisResult from '../components/AnalysisResult'

export default function AnalyzePage() {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-4">Analyze Your Dream</h2>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <DreamForm />
          </div>
        </div>
        <div className="mt-8">
          <AnalysisResult />
        </div>
      </div>
    </div>
  )
}

