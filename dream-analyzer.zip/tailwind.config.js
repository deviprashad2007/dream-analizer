/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
	],
  theme: {
    extend: {
      colors: {
        dream: {
          50: '#f0f8ff',
          100: '#dff0ff',
          200: '#b8e2ff',
          300: '#8ad2ff',
          400: '#33b3fd',
          500: '#0999ee',
          600: '#0078cc',
          700: '#0060a5',
          800: '#045288',
          900: '#0a4570',
          950: '#062b4b',
        },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

